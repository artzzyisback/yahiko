import os
#WokszXDStore
#JarzTunnel
#ArtzzyIsBack
# Warna Terminal
class Colors:
    RED = '\033[31m'
    GREEN = '\033[32m'
    YELLOW = '\033[33m'
    BLUE = '\033[34m'
    PURPLE = '\033[35m'
    CYAN = '\033[36m'
    LIGHT = '\033[37m'
    NC = '\033[0m'  # Reset warna

def purple(text): print(f"{Colors.PURPLE}{text}{Colors.NC}")
def cyan(text): print(f"{Colors.CYAN}{text}{Colors.NC}")
def green(text): print(f"{Colors.GREEN}{text}{Colors.NC}")
def red(text): print(f"{Colors.RED}{text}{Colors.NC}")

def menu():
    while True:
        os.system("clear")
        purple("=== MENU UTAMA ===")
        print(f"{Colors.GREEN}1. Install Tools{Colors.NC}")
        print(f"{Colors.GREEN}2. Install WebSocket{Colors.NC}")
        print(f"{Colors.GREEN}3. Install Xray{Colors.NC}")
        print(f"{Colors.RED}0. Keluar{Colors.NC}")

        choice = input("Pilih menu: ")

        if choice == "1":
            os.system("python3 toolsinstaller.py")
        elif choice == "2":
            os.system("python3 websocketinstaller.py")
        elif choice == "3":
            os.system("python3 xrayinstaller.py")
        elif choice == "0":
            green("Keluar dari menu.")
            break
        else:
            red("Pilihan tidak valid!")

if __name__ == "__main__":
    menu()