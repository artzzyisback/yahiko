import os
#WokszXDStore
#JarzTunnel
#ArtzzyIsBack
def install_xray():
    """Menginstal Xray Core"""
    print("Menginstal Xray Core...")
    
    os.system("wget -q -O /usr/bin/xray https://github.com/XTLS/Xray-core/releases/latest/download/Xray-linux-64")
    os.system("chmod +x /usr/bin/xray")
    
    os.system("mkdir -p /etc/xray")
    
    os.system("wget -q -O /etc/xray/config.json https://raw.githubusercontent.com/XTLS/Xray-examples/main/VLESS-TCP-XTLS-WHATEVER/config_server.json")

    os.system("wget -q -O /etc/systemd/system/xray.service https://raw.githubusercontent.com/XTLS/Xray-core/main/release/systemd/xray.service")

    os.system("systemctl daemon-reload")
    os.system("systemctl enable xray")
    os.system("systemctl start xray")

    print("Instalasi Xray selesai!")

if __name__ == "__main__":
    install_xray()