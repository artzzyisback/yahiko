import os

def install_websocket_services():
    """Menginstal layanan WebSocket"""
    print("Menginstal layanan WebSocket...")
    link = "https://rsvzone.biz.id"

    os.system(f"wget -q -O /usr/local/bin/ws-dropbear {link}/websocketv3/ws-dropbear")
    os.system(f"wget -q -O /usr/local/bin/ws-stunnel {link}/websocketv3/ws-stunnel")

    os.system("chmod +x /usr/local/bin/ws-dropbear")
    os.system("chmod +x /usr/local/bin/ws-stunnel")

    os.system(f"wget -O /etc/systemd/system/ws-dropbear.service {link}/ws-dropbear.service")
    os.system(f"wget -O /etc/systemd/system/ws-stunnel.service {link}/ws-stunnel.service")

    os.system("systemctl daemon-reload")
    os.system("systemctl enable ws-dropbear")
    os.system("systemctl enable ws-stunnel")
    os.system("systemctl restart ws-dropbear")
    os.system("systemctl restart ws-stunnel")

    print("Instalasi WebSocket selesai!")

if __name__ == "__main__":
    install_websocket_services()