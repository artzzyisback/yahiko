import os
#WokszXDStore
#JarzTunnel
#ArtzzyIsBack
def install_tools():
    """Menginstal paket yang diperlukan"""
    os.system("apt update -y && apt upgrade -y")
    os.system("apt install wget curl socat -y")
    os.system("apt install python3 python3-pip -y")

    print("Instalasi tools selesai!")

if __name__ == "__main__":
    install_tools()