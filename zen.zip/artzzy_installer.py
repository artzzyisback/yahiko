import os
import subprocess
import requests

# Direktori untuk validasi data
SECUREDATA_DIR = "/etc/securedata"
FILES = ["ip1", "chatidbw", "name", "chatidbak"]

def run_command(command):
    """Menjalankan perintah shell."""
    subprocess.run(command, shell=True, check=True)

def setup_secure_data():
    print("Setting up secure data directory...")

    # Membuat direktori jika belum ada
    if not os.path.exists(SECUREDATA_DIR):
        os.makedirs(SECUREDATA_DIR)

    # Membuat file kosong jika belum ada
    for file in FILES:
        file_path = os.path.join(SECUREDATA_DIR, file)
        if not os.path.exists(file_path):
            open(file_path, "w").close()

    print("Secure data directory set up successfully.")

def install_dependencies():
    print("Installing dependencies...")
    run_command("apt install -y jq curl sudo")
    print("Dependencies installed.")

def get_public_ip():
    print("Fetching public IP address...")
    try:
        response = requests.get("https://ipv4.icanhazip.com")
        ip = response.text.strip()
        with open(os.path.join(SECUREDATA_DIR, "ip1"), "w") as f:
            f.write(ip)
        print(f"Public IP saved: {ip}")
    except Exception as e:
        print(f"Failed to fetch public IP: {e}")

if __name__ == "__main__":
    setup_secure_data()
    install_dependencies()
    get_public_ip()