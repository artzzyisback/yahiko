import os
import subprocess
import platform

# Fungsi untuk menjalankan perintah shell dengan output langsung
def run_command(command):
    subprocess.run(command, shell=True, check=True)

# Deteksi sistem operasi
os_release = platform.system().lower()

if os.path.exists("/etc/debian_version"):
    os_type = "debian"
elif os.path.exists("/etc/centos-release"):
    os_type = "centos"
else:
    os_type = "unknown"

print(f"Detected OS: {os_type}")

# Instal paket yang diperlukan berdasarkan OS
if os_type in ["debian", "ubuntu"]:
    packages = ["netfilter-persistent", "screen", "curl", "jq", "bzip2"]
    remove_packages = ["ufw", "firewalld", "exim4"]
    run_command(f"sudo apt-get install -y {' '.join(packages)}")
    run_command(f"sudo apt-get remove --purge -y {' '.join(remove_packages)}")

elif os_type == "centos":
    packages = ["epel-release", "screen", "curl", "jq", "bzip2"]
    remove_packages = ["firewalld", "postfix"]
    run_command(f"sudo yum install -y {' '.join(packages)}")
    run_command(f"sudo yum remove -y {' '.join(remove_packages)}")

else:
    print("Unsupported OS")

print("Installation complete.")