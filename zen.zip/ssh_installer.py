import os
import subprocess

SSH_CONFIG_PATH = "/etc/ssh/sshd_config"

def run_command(command):
    """Menjalankan perintah shell."""
    subprocess.run(command, shell=True, check=True)

def install_ssh():
    print("Installing SSH Server...")

    # Menginstal OpenSSH Server jika belum terpasang
    run_command("apt-get update -y && apt-get install -y openssh-server")

    # Mengonfigurasi SSH (Contoh: Mengaktifkan Root Login)
    with open(SSH_CONFIG_PATH, "r") as f:
        config = f.readlines()

    new_config = []
    for line in config:
        if line.strip().startswith("PermitRootLogin"):
            new_config.append("PermitRootLogin yes\n")
        else:
            new_config.append(line)

    with open(SSH_CONFIG_PATH, "w") as f:
        f.writelines(new_config)

    # Mengaktifkan dan memulai layanan SSH
    run_command("systemctl enable ssh")
    run_command("systemctl restart ssh")

    print("SSH installation and configuration completed!")

if __name__ == "__main__":
    install_ssh()