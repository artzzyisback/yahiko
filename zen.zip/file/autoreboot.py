import os
import subprocess

CRON_JOB = "0 5 * * * /sbin/reboot"  # Reboot setiap hari pukul 05:00
CRON_FILE = "/etc/cron.d/autoreboot"

def run_command(command):
    """Menjalankan perintah shell."""
    subprocess.run(command, shell=True, check=True)

def setup_autoreboot():
    print("Setting up automatic reboot...")

    # Menulis cron job ke dalam file
    with open(CRON_FILE, "w") as f:
        f.write(CRON_JOB + "\n")

    # Memberikan izin eksekusi
    run_command(f"chmod 644 {CRON_FILE}")

    # Memuat ulang layanan cron
    run_command("systemctl restart cron")

    print("Automatic reboot configured successfully.")

if __name__ == "__main__":
    setup_autoreboot()