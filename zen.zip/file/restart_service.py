import subprocess

# Daftar layanan yang akan direstart
SERVICES = [
    "ssh",
    "dropbear",
    "ws-dropbear",
    "ws-stunnel",
    "stunnel4",
    "xray",
    "cron"
]

def run_command(command):
    """Menjalankan perintah shell."""
    subprocess.run(command, shell=True, check=True)

def restart_services():
    print("Restarting services...")

    for service in SERVICES:
        print(f"Restarting {service}...")
        run_command(f"systemctl restart {service}")

    print("All services restarted successfully.")

if __name__ == "__main__":
    restart_services()