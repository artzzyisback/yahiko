import os
import subprocess
import shutil
from datetime import datetime

# Direktori tujuan pencadangan
BACKUP_DIR = "/root/backup"
FILES_TO_BACKUP = ["/etc/passwd", "/etc/group", "/etc/shadow", "/etc/gshadow"]

def run_command(command):
    """Menjalankan perintah shell."""
    subprocess.run(command, shell=True, check=True)

def create_backup():
    print("Starting backup process...")

    # Membuat folder backup jika belum ada
    if not os.path.exists(BACKUP_DIR):
        os.makedirs(BACKUP_DIR)

    # Menyalin file yang ingin dicadangkan
    for file in FILES_TO_BACKUP:
        if os.path.exists(file):
            shutil.copy(file, BACKUP_DIR)
            print(f"Backed up: {file}")

    # Mengarsipkan backup
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    archive_name = f"/root/backup_{timestamp}.tar.gz"
    run_command(f"tar -czf {archive_name} -C {BACKUP_DIR} .")

    print(f"Backup completed: {archive_name}")

if __name__ == "__main__":
    create_backup()