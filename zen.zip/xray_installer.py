import os
import subprocess

XRAY_URL = "https://github.com/XTLS/Xray-core/releases/latest/download/Xray-linux-amd64.zip"
XRAY_PATH = "/usr/local/bin/xray"
CONFIG_PATH = "/etc/xray/config.json"

def run_command(command):
    """Menjalankan perintah shell."""
    subprocess.run(command, shell=True, check=True)

def install_xray():
    print("Installing Xray VPN...")

    # Membuat direktori jika belum ada
    run_command("mkdir -p /etc/xray")
    run_command("mkdir -p /usr/local/bin")

    # Mengunduh dan mengekstrak Xray
    run_command(f"wget -q -O /tmp/xray.zip {XRAY_URL}")
    run_command("unzip -o /tmp/xray.zip -d /usr/local/bin/")
    run_command("chmod +x /usr/local/bin/xray")

    # Menyiapkan layanan systemd
    with open("/etc/systemd/system/xray.service", "w") as f:
        f.write("""[Unit]
Description=Xray VPN Service
After=network.target

[Service]
ExecStart=/usr/local/bin/xray -config /etc/xray/config.json
Restart=always
User=root

[Install]
WantedBy=multi-user.target
""")

    # Mengaktifkan dan memulai layanan
    run_command("systemctl daemon-reload")
    run_command("systemctl enable xray")
    run_command("systemctl start xray")

    print("Xray installation completed!")

if __name__ == "__main__":
    install_xray()