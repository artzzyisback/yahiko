import os
import subprocess

# URL sumber file yang akan diunduh
BASE_URL = "https://rsvzone.biz.id/websocketv3"

# File yang perlu diunduh
FILES = {
    "/usr/local/bin/ws-dropbear": "ws-dropbear",
    "/usr/local/bin/ws-stunnel": "ws-stunnel",
    "/etc/systemd/system/ws-dropbear.service": "ws-dropbear.service",
    "/etc/systemd/system/ws-stunnel.service": "ws-stunnel.service",
}

def run_command(command):
    """Menjalankan perintah shell."""
    subprocess.run(command, shell=True, check=True)

def download_file(url, destination):
    """Mengunduh file dari URL ke lokasi tertentu."""
    run_command(f"wget -q -O {destination} {url}")

def install_websocket_services():
    print("Installing WebSocket Services...")

    # Mengunduh file dari server
    for destination, filename in FILES.items():
        download_file(f"{BASE_URL}/{filename}", destination)
    
    # Mengatur izin eksekusi
    run_command("chmod +x /usr/local/bin/ws-dropbear")
    run_command("chmod +x /usr/local/bin/ws-stunnel")

    # Mengaktifkan layanan
    run_command("systemctl daemon-reload")
    run_command("systemctl enable ws-dropbear")
    run_command("systemctl enable ws-stunnel")
    run_command("systemctl restart ws-dropbear")
    run_command("systemctl restart ws-stunnel")

    print("WebSocket installation completed!")

if __name__ == "__main__":
    install_websocket_services()